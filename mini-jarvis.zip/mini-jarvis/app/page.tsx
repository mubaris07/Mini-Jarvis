'use client';

import { useState, useCallback, useRef } from 'react';
import JarvisCore from '@/components/JarvisCore';
import Transcript from '@/components/Transcript';
import ControlPanel from '@/components/ControlPanel';
import { useSpeechRecognition } from '@/hooks/useSpeechRecognition';
import { useSpeechSynthesis, type SpeechOptions } from '@/hooks/useSpeechSynthesis';
import type { JarvisMessage, JarvisApiResponse, JarvisApiError } from '@/types';

export default function Home() {
  const [messages, setMessages] = useState<JarvisMessage[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [voiceOptions, setVoiceOptions] = useState<SpeechOptions>({
    pitch: 0.8,
    rate: 1.05,
    volume: 1,
  });

  // Kept in sync with `messages` so the async fetch callback always sees
  // the latest history without needing to be re-created every render.
  const messagesRef = useRef<JarvisMessage[]>([]);
  messagesRef.current = messages;

  const { isSpeaking, isSupported: synthSupported, speak, cancel } = useSpeechSynthesis();

  const handleFinalTranscript = useCallback(
    async (text: string) => {
      if (!text) return;

      const userMessage: JarvisMessage = {
        id: crypto.randomUUID(),
        role: 'user',
        content: text,
        timestamp: Date.now(),
      };

      setMessages((prev) => [...prev, userMessage]);
      setIsProcessing(true);
      cancel();

      try {
        const response = await fetch('/api/jarvis', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            transcript: text,
            history: messagesRef.current,
          }),
        });

        const data: JarvisApiResponse | JarvisApiError = await response.json();

        if (!response.ok || 'error' in data) {
          const errorText =
            'error' in data ? data.error : 'Something went wrong reaching Jarvis.';
          const errorMessage: JarvisMessage = {
            id: crypto.randomUUID(),
            role: 'assistant',
            content: `Error: ${errorText}`,
            timestamp: Date.now(),
          };
          setMessages((prev) => [...prev, errorMessage]);
          return;
        }

        const assistantMessage: JarvisMessage = {
          id: crypto.randomUUID(),
          role: 'assistant',
          content: data.reply,
          timestamp: Date.now(),
        };
        setMessages((prev) => [...prev, assistantMessage]);
        speak(data.reply, voiceOptions);
      } catch (err) {
        console.error('Failed to reach Jarvis API:', err);
        const errorMessage: JarvisMessage = {
          id: crypto.randomUUID(),
          role: 'assistant',
          content: 'Error: Unable to reach the server.',
          timestamp: Date.now(),
        };
        setMessages((prev) => [...prev, errorMessage]);
      } finally {
        setIsProcessing(false);
      }
    },
    [speak, cancel, voiceOptions]
  );

  const {
    interimTranscript,
    isListening,
    isSupported: recognitionSupported,
    startListening,
    stopListening,
  } = useSpeechRecognition(handleFinalTranscript);

  const handleToggleListening = useCallback(() => {
    if (isListening) {
      stopListening();
    } else {
      cancel();
      startListening();
    }
  }, [isListening, startListening, stopListening, cancel]);

  const handleClear = useCallback(() => {
    setMessages([]);
    cancel();
  }, [cancel]);

  return (
    <main className="flex min-h-screen w-full flex-col items-center bg-[radial-gradient(ellipse_at_top,_#0a1929_0%,_#000000_70%)] px-4 py-8 text-white">
      <header className="mb-6 text-center">
        <h1 className="font-mono text-2xl font-bold tracking-[0.4em] text-cyan-300">
          MINI-JARVIS
        </h1>
        <p className="mt-1 font-mono text-[10px] tracking-widest text-cyan-700">
          PERSONAL AI INTERFACE
        </p>
      </header>

      <JarvisCore
        isListening={isListening}
        isSpeaking={isSpeaking}
        isProcessing={isProcessing}
      />

      <div className="mt-8 flex w-full max-w-xl flex-1 flex-col gap-4">
        <div className="h-72 w-full">
          <Transcript messages={messages} interimText={interimTranscript} />
        </div>
        <ControlPanel
          isListening={isListening}
          isSupported={recognitionSupported}
          synthSupported={synthSupported}
          onToggleListening={handleToggleListening}
          voiceOptions={voiceOptions}
          onVoiceOptionsChange={setVoiceOptions}
          onClear={handleClear}
        />
      </div>
    </main>
  );
}
