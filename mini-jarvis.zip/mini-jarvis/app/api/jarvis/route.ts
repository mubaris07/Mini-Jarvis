import { NextRequest, NextResponse } from 'next/server';
import type {
  JarvisApiRequest,
  JarvisApiResponse,
  JarvisApiError,
  JarvisMessage,
} from '@/types';

const SYSTEM_PROMPT =
  'You are Jarvis, the highly sophisticated, slightly sarcastic, and deeply loyal AI assistant to Tony Stark. Keep answers punchy, helpful, and brief.';

const OPENAI_URL = 'https://api.openai.com/v1/chat/completions';
const MODEL = 'gpt-4o-mini';
const MAX_HISTORY_MESSAGES = 10;

export async function POST(
  request: NextRequest
): Promise<NextResponse<JarvisApiResponse | JarvisApiError>> {
  const apiKey = process.env.OPENAI_API_KEY;

  if (!apiKey) {
    return NextResponse.json(
      { error: 'OPENAI_API_KEY is not configured on the server.' },
      { status: 500 }
    );
  }

  let body: JarvisApiRequest;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: 'Invalid JSON body.' }, { status: 400 });
  }

  const transcript = body.transcript?.trim();
  if (!transcript) {
    return NextResponse.json({ error: 'Transcript is required.' }, { status: 400 });
  }

  const history: JarvisMessage[] = Array.isArray(body.history) ? body.history : [];
  const recentHistory = history.slice(-MAX_HISTORY_MESSAGES);

  const messages = [
    { role: 'system' as const, content: SYSTEM_PROMPT },
    ...recentHistory.map((m) => ({
      role: m.role as 'user' | 'assistant',
      content: m.content,
    })),
    { role: 'user' as const, content: transcript },
  ];

  try {
    const openaiResponse = await fetch(OPENAI_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: MODEL,
        messages,
        temperature: 0.7,
        max_tokens: 300,
      }),
    });

    if (!openaiResponse.ok) {
      const errText = await openaiResponse.text();
      console.error('OpenAI API error:', openaiResponse.status, errText);
      return NextResponse.json(
        { error: `OpenAI API request failed with status ${openaiResponse.status}.` },
        { status: 502 }
      );
    }

    const data = await openaiResponse.json();
    const reply: string | undefined = data?.choices?.[0]?.message?.content;

    if (!reply) {
      return NextResponse.json(
        { error: 'No response content received from OpenAI.' },
        { status: 502 }
      );
    }

    return NextResponse.json({ reply: reply.trim() }, { status: 200 });
  } catch (err) {
    console.error('Jarvis API route error:', err);
    return NextResponse.json(
      { error: 'Internal server error while contacting OpenAI.' },
      { status: 500 }
    );
  }
}
