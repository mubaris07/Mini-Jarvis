# Mini-Jarvis

A voice-controlled personal AI assistant dashboard built with Next.js 15 (App Router), TypeScript, and Tailwind CSS. Uses the browser's native Web Speech API for mic input + voice output, and a Next.js API route to talk to OpenAI.

## 1. Initialize the project

If you're starting from these files directly, skip `create-next-app` and just install dependencies (step 2) — the project is already scaffolded.

If you want to regenerate the scaffold yourself from scratch instead:

```bash
npx create-next-app@latest mini-jarvis --typescript --tailwind --app --no-src-dir --import-alias "@/*"
cd mini-jarvis
```

Then copy the files from `app/`, `components/`, `hooks/`, and `types/` in this project over the generated ones.

## 2. Install dependencies

From inside the `mini-jarvis` folder:

```bash
npm install
```

## 3. Configure your OpenAI API key

Copy the example env file and add your key:

```bash
cp .env.local.example .env.local
```

Edit `.env.local`:

```
OPENAI_API_KEY=sk-your-openai-api-key-here
```

`.env.local` is git-ignored by default in Next.js projects — never commit it.

## 4. Run the dev server

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000). Chrome or Edge is recommended — Web Speech API (`SpeechRecognition`) support is inconsistent in Firefox and Safari.

## 5. Build for production

```bash
npm run build
npm run start
```

## Project structure

```
mini-jarvis/
├── app/
│   ├── api/
│   │   └── jarvis/
│   │       └── route.ts       # POST handler -> OpenAI chat completions
│   ├── globals.css            # Tailwind + glow-ring keyframes
│   ├── layout.tsx             # Root layout, metadata
│   └── page.tsx                # Main dashboard (client component)
├── components/
│   ├── ControlPanel.tsx       # Mic button, pitch/rate sliders
│   ├── JarvisCore.tsx         # Animated glowing core/ring
│   └── Transcript.tsx         # Conversation log
├── hooks/
│   ├── useSpeechRecognition.ts # Wraps SpeechRecognition
│   └── useSpeechSynthesis.ts   # Wraps SpeechSynthesis
├── types/
│   └── index.ts                # Shared TS interfaces
├── .env.local.example
├── next.config.js
├── package.json
├── postcss.config.js
├── tailwind.config.ts
└── tsconfig.json
```

## How it works

1. Click **ACTIVATE MIC** — `useSpeechRecognition` starts the browser's native `SpeechRecognition`, streaming interim (gray/italic) and final transcript text live.
2. When a chunk of speech is finalized, `page.tsx` POSTs it (plus recent chat history) to `/api/jarvis`.
3. The route handler calls the OpenAI Chat Completions API server-side (your key never reaches the browser) with the Jarvis system prompt, and returns the reply.
4. The reply is added to the transcript and spoken aloud via `useSpeechSynthesis`, using the pitch/rate you've set in the control panel.
5. The central ring glows cyan while listening, amber while waiting on the API, and green while Jarvis is speaking.

## Notes

- The API route defaults to `gpt-4o-mini` for speed/cost — change `MODEL` in `app/api/jarvis/route.ts` if you want a different model.
- Speech recognition requires HTTPS in production (or `localhost` in dev) and an explicit mic permission grant.
- Voice selection: the synthesis hook tries to auto-pick a deeper male-sounding system voice; pass `voiceName` in `voiceOptions` if you want to hardcode a specific one from `speechSynthesis.getVoices()`.
