export interface JarvisMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: number;
}

export interface JarvisApiRequest {
  transcript: string;
  history: JarvisMessage[];
}

export interface JarvisApiResponse {
  reply: string;
}

export interface JarvisApiError {
  error: string;
}
