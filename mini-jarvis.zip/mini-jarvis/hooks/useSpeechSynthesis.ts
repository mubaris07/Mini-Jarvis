'use client';

import { useState, useCallback, useEffect, useRef } from 'react';

export interface SpeechOptions {
  pitch: number;
  rate: number;
  volume: number;
  voiceName?: string;
}

export interface UseSpeechSynthesisReturn {
  isSpeaking: boolean;
  isSupported: boolean;
  voices: SpeechSynthesisVoice[];
  speak: (text: string, options?: Partial<SpeechOptions>) => void;
  cancel: () => void;
}

const DEFAULT_OPTIONS: SpeechOptions = {
  pitch: 0.8,
  rate: 1.05,
  volume: 1,
};

/**
 * Wraps the browser's native Web Speech Synthesis API in a React hook.
 * Speaks text aloud with a configurable pitch/rate, auto-selecting a
 * deeper-sounding voice by default for the "Jarvis" effect.
 */
export function useSpeechSynthesis(): UseSpeechSynthesisReturn {
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isSupported, setIsSupported] = useState(false);
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);
  const utteranceRef = useRef<SpeechSynthesisUtterance | null>(null);

  useEffect(() => {
    if (typeof window === 'undefined' || !window.speechSynthesis) {
      setIsSupported(false);
      return;
    }
    setIsSupported(true);

    const loadVoices = () => {
      setVoices(window.speechSynthesis.getVoices());
    };

    loadVoices();
    window.speechSynthesis.onvoiceschanged = loadVoices;

    return () => {
      window.speechSynthesis.onvoiceschanged = null;
    };
  }, []);

  const speak = useCallback(
    (text: string, options?: Partial<SpeechOptions>) => {
      if (!isSupported || !text) return;

      window.speechSynthesis.cancel();

      const merged = { ...DEFAULT_OPTIONS, ...options };
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.pitch = merged.pitch;
      utterance.rate = merged.rate;
      utterance.volume = merged.volume;

      if (merged.voiceName) {
        const match = voices.find((v) => v.name === merged.voiceName);
        if (match) utterance.voice = match;
      } else {
        const preferred = voices.find(
          (v) => v.lang.startsWith('en') && /male|daniel|google uk english male/i.test(v.name)
        );
        if (preferred) utterance.voice = preferred;
      }

      utterance.onstart = () => setIsSpeaking(true);
      utterance.onend = () => setIsSpeaking(false);
      utterance.onerror = () => setIsSpeaking(false);

      utteranceRef.current = utterance;
      window.speechSynthesis.speak(utterance);
    },
    [isSupported, voices]
  );

  const cancel = useCallback(() => {
    if (!isSupported) return;
    window.speechSynthesis.cancel();
    setIsSpeaking(false);
  }, [isSupported]);

  return { isSpeaking, isSupported, voices, speak, cancel };
}
