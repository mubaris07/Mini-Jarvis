'use client';

interface JarvisCoreProps {
  isListening: boolean;
  isSpeaking: boolean;
  isProcessing: boolean;
}

export default function JarvisCore({ isListening, isSpeaking, isProcessing }: JarvisCoreProps) {
  const active = isListening || isSpeaking || isProcessing;

  const statusLabel = isListening
    ? 'LISTENING'
    : isProcessing
    ? 'PROCESSING'
    : isSpeaking
    ? 'SPEAKING'
    : 'STANDBY';

  const ringColor = isListening
    ? 'border-cyan-400'
    : isProcessing
    ? 'border-amber-400'
    : isSpeaking
    ? 'border-emerald-400'
    : 'border-cyan-900';

  const glowColor = isListening
    ? 'shadow-[0_0_60px_10px_rgba(34,211,238,0.5)]'
    : isProcessing
    ? 'shadow-[0_0_60px_10px_rgba(251,191,36,0.5)]'
    : isSpeaking
    ? 'shadow-[0_0_60px_10px_rgba(52,211,153,0.5)]'
    : 'shadow-[0_0_20px_2px_rgba(8,145,178,0.2)]';

  return (
    <div className="relative flex flex-col items-center justify-center select-none">
      <div className="relative h-64 w-64 md:h-80 md:w-80">
        <div
          className={`absolute inset-0 rounded-full border-2 ${ringColor} ${glowColor} transition-all duration-500 ${
            active ? 'animate-spin-slow' : ''
          }`}
        />
        <div
          className={`absolute inset-6 rounded-full border ${ringColor} opacity-60 transition-all duration-500 ${
            active ? 'animate-spin-reverse' : ''
          }`}
        />
        <div
          className={`absolute inset-12 rounded-full border ${ringColor} opacity-40 transition-all duration-500 ${
            active ? 'animate-spin-slow' : ''
          }`}
        />
        <div
          className={`absolute inset-20 rounded-full bg-gradient-to-br from-cyan-500/30 to-transparent transition-all duration-500 ${
            active ? 'animate-pulse-glow' : ''
          }`}
        />
        <div className="absolute inset-0 flex items-center justify-center">
          <div
            className={`h-4 w-4 rounded-full bg-cyan-300 transition-all duration-300 ${
              active ? 'animate-pulse scale-150' : 'scale-100'
            }`}
          />
        </div>
      </div>
      <p className="mt-6 font-mono text-xs tracking-[0.3em] text-cyan-400/80">
        {statusLabel}
      </p>
    </div>
  );
}
