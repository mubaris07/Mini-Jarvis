'use client';

import type { SpeechOptions } from '@/hooks/useSpeechSynthesis';

interface ControlPanelProps {
  isListening: boolean;
  isSupported: boolean;
  synthSupported: boolean;
  onToggleListening: () => void;
  voiceOptions: SpeechOptions;
  onVoiceOptionsChange: (options: SpeechOptions) => void;
  onClear: () => void;
}

export default function ControlPanel({
  isListening,
  isSupported,
  synthSupported,
  onToggleListening,
  voiceOptions,
  onVoiceOptionsChange,
  onClear,
}: ControlPanelProps) {
  return (
    <div className="flex w-full flex-col gap-4 rounded-lg border border-cyan-900/50 bg-black/40 p-4 backdrop-blur-sm">
      <div className="flex items-center justify-between gap-3">
        <button
          onClick={onToggleListening}
          disabled={!isSupported}
          className={`flex-1 rounded-md px-4 py-3 font-mono text-sm font-semibold tracking-wide transition-all ${
            isListening
              ? 'bg-red-500/20 text-red-300 ring-1 ring-red-400 hover:bg-red-500/30'
              : 'bg-cyan-500/20 text-cyan-300 ring-1 ring-cyan-400 hover:bg-cyan-500/30'
          } disabled:cursor-not-allowed disabled:opacity-40`}
        >
          {isListening ? '■ STOP LISTENING' : '● ACTIVATE MIC'}
        </button>
        <button
          onClick={onClear}
          className="rounded-md border border-cyan-900/60 px-4 py-3 font-mono text-xs text-cyan-500 hover:bg-cyan-900/20"
        >
          CLEAR
        </button>
      </div>

      {!isSupported && (
        <p className="font-mono text-xs text-amber-400">
          Speech recognition isn&apos;t supported in this browser. Try Chrome or Edge on desktop.
        </p>
      )}
      {!synthSupported && (
        <p className="font-mono text-xs text-amber-400">
          Speech synthesis isn&apos;t supported in this browser.
        </p>
      )}

      <div className="grid grid-cols-2 gap-4 font-mono text-xs text-cyan-400">
        <label className="flex flex-col gap-1">
          PITCH: {voiceOptions.pitch.toFixed(2)}
          <input
            type="range"
            min={0}
            max={2}
            step={0.05}
            value={voiceOptions.pitch}
            onChange={(e) =>
              onVoiceOptionsChange({ ...voiceOptions, pitch: Number(e.target.value) })
            }
            className="accent-cyan-400"
          />
        </label>
        <label className="flex flex-col gap-1">
          RATE: {voiceOptions.rate.toFixed(2)}
          <input
            type="range"
            min={0.5}
            max={2}
            step={0.05}
            value={voiceOptions.rate}
            onChange={(e) =>
              onVoiceOptionsChange({ ...voiceOptions, rate: Number(e.target.value) })
            }
            className="accent-cyan-400"
          />
        </label>
      </div>
    </div>
  );
}
