'use client';

import type { JarvisMessage } from '@/types';

interface TranscriptProps {
  messages: JarvisMessage[];
  interimText: string;
}

export default function Transcript({ messages, interimText }: TranscriptProps) {
  return (
    <div className="flex h-full w-full flex-col gap-3 overflow-y-auto rounded-lg border border-cyan-900/50 bg-black/40 p-4 font-mono text-sm backdrop-blur-sm">
      {messages.length === 0 && !interimText && (
        <p className="text-cyan-700/60">// awaiting input...</p>
      )}
      {messages.map((msg) => (
        <div key={msg.id} className="flex flex-col gap-1">
          <span
            className={`text-[10px] uppercase tracking-widest ${
              msg.role === 'user' ? 'text-cyan-500' : 'text-emerald-400'
            }`}
          >
            {msg.role === 'user' ? 'You' : 'Jarvis'}
          </span>
          <p className={msg.role === 'user' ? 'text-cyan-100' : 'text-emerald-100'}>
            {msg.content}
          </p>
        </div>
      ))}
      {interimText && (
        <div className="flex flex-col gap-1 opacity-60">
          <span className="text-[10px] uppercase tracking-widest text-cyan-500">You</span>
          <p className="italic text-cyan-200">{interimText}</p>
        </div>
      )}
    </div>
  );
}
